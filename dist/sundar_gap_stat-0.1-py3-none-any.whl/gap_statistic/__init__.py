# gap_statistic/__init__.py

from gap_statistic.gap_stat import SundarTibshiraniGapStatistic
from .utils import sundar_tibshirani_gap_statistic_main
__all__ = ['SundarTibshiraniGapStatistic', 'sundar_tibshirani_gap_statistic_main']
